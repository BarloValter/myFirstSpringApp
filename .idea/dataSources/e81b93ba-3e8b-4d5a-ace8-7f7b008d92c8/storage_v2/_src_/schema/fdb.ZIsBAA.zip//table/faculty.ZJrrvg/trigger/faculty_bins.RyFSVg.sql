create definer = root@localhost trigger Faculty_BINS
    before insert
    on faculty
    for each row
BEGIN
    
    IF (NEW.budget_places > NEW.total_places) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Budget places amount must be lower then total.', MYSQL_ERRNO = 1001;
    END IF;
END;

