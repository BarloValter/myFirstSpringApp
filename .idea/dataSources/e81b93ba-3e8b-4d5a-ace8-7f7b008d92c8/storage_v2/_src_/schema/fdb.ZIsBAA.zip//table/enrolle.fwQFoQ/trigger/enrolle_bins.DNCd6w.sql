create definer = root@localhost trigger Enrolle_BINS
    before insert
    on enrolle
    for each row
BEGIN
    
    IF (SELECT user.role FROM user WHERE NEW.user_id=User.id)='admin' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Admins are not allowed to have Enrolle record', MYSQL_ERRNO = 1001;
    END IF;
END;

